#include<iostream> 
#define SIZE 20 
using namespace std; 
int main()
{
int vertex[SIZE],edge[SIZE][SIZE]; 
int i,j,k,no_edges,no_vertex,from,to; 
cout<<"enter number of vertices\n"; 
cin>>no_vertex;
cout<<"enter vertices: "<<endl; 
for(i=0;i<no_vertex;i++)
cin>>vertex[i]; 
cout<<"enter number of edges\n"; 
cin>>no_edges; 
for(i=1;i<=no_vertex;i++)
for(j=1;j<=no_vertex;j++) 
edge[i][j]=0;
for(i=1;i<=no_edges;i++)
{
cout<<"Enter from vertex\n"; 
cin>>from;
cout<<"Enter to vertex\n"; 
cin>>to; 
edge[from][to]=1; 
edge[to][from]=1;
}
cout<<"\n\nOutput:\n";
cout<<"The vertices in graph are:\n"<<endl; 
for(i=0;i<no_vertex;i++)
cout<<vertex[i]<<"\t"; 
cout<<"\n Adjecancy matrix for a graph is\n";
for(i=1;i<=no_vertex;i++)
{
for(j=1;j<=no_vertex;j++) 
cout<<"\t"<<edge[i][j];
cout<<"\n";
}
}
