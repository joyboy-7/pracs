//selecction

#include<iostream>
using namespace std;
int main(){
	int n;
	int i,t,temp,j,small,walk,current;
	cout<<"Enter array size";
	cin>>n;
	int a[n];
	cout<<"enter elemet of array to be sort\n";
	for(i=0;i<n;i++){
		cin>>a[i];
	}
	current=0;
	while(current<n)
	{
		small=current;
		walk=current+1;
		
		while(walk<=n)
		{
			if(a[walk]<a[small])
			small=walk;
			walk=walk+1;
		}
		temp=a[current];
		a[current]=a[small];
		a[small]=temp;
		current++;
	}
		cout<<"print sorted array:\n";
	for(i=1;i<=n;i++)
	{ 
		cout<<a[i]<<"\t";
		
	}
		return 0;
	}
