#include<iostream>
#include<conio.h>
#define SIZE 10

using namespace std;
int main(){
	int arr[SIZE];
	int n;
	cout<<"enter array size";
	cin>>n;
	cout<<"enter element";
	for(int i=0;i<n;i++)
	{
		cin>>arr[i];
	}
	cout<<"elemet are\n";
	for(int i=0;i<n;i++)
	{
		cout<<arr[i]<<"\t";
	}
	return 0;
}
