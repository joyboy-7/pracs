#include<iostream>
#define n 50
using namespace std;

class stack{
	int* a;
	int top;
	public:
		stack(){
			a=new int [n];
			top=-1;
		}
		void push(int x){
			if(top==n-1){
				cout<<"stack Full\n";
				return;
			}
			top++;
			a[top]=x;
			
		}
		void pop(){
			if(top==-1){
				cout<<"empty stack\n";
				return;
			}
			top--;
			
		}
		int Top(){
			if(top==-1){
				cout<<"no element\n";
				return -1;
			}
			return a[top];
		}
		bool empty(){
			return top==-1;
		}
};


int main(){
	stack st;
	st.push(2);
	st.push(24); 
	st.push(25);
	st.push(26);
	cout<<st.Top()<<"\t";
	st.pop();
	cout<<st.Top()<<"\t";
	st.push(99);
	cout<<st.Top()<<"\t";


	
	
	
	
	
	return 0;
}
