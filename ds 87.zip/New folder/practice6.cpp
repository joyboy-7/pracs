/// insertion sort by yt
#include<iostream>
using namespace std;
int main(){
	int n;
	int i,t,temp,j;
	cout<<"Enter array size";
	cin>>n;
	int a[n];
	cout<<"enter elemet of array to be sort\n";
	for(i=0;i<n;i++){
		cin>>a[i];
	}
	for (i=1;i<n;i++)
	{
		int current=a[i];
		int j=i-1;
		
		while(a[j]>current && a[j]>=0){
			a[j+1]=a[j];
			j--;
		}
		a[j+1]=current;
	}
	cout<<"print sorted array:\n";
	for(i=0;i<n;i++)
	{
		cout<<a[i]<<"\t";
		
	}
	return 0;
}
