#include<iostream>
using namespace std;
#define n 50
class queue{
	int* a;
	int front;
	int back;
	
	public:
		queue(){
			a=new int[n];
			front = -1;
			back=-1;
		}
		void dequeue(){
			if(front==-1 &&front>back ){
				cout<<"Queue is empty\n";
				return;
			}
			front++;
		}
		void enqueue(int x){
			if(back==n-1){
				cout<<"Queue if Full\n";
				return;
			}
			back++;
			a[back]=x;
			
			if(front==-1){
				front++;
			}
		}
		int peek(){
			if(front==-1 &&front>back ){
				cout<<"Queue is empty\n";
				
			}
			return a[front];
		}
		bool empty(){
			if(front==-1 &&front>back ){
				return true;
			}
			return false;
			
		}
		
			
		
};

int main(){
	queue q;
	q.enqueue(10);
	cout<<q.peek();
	return 0;
}
