#include<iostream>
#include<conio.h>
#include<stdlib.h>
using namespace std;

void shellsort(int a[], int n){
	for (int gap=n/2;gap>0;gap=gap/2)
	{
		for(int j=gap;j<n;j+=1)
		{
			int temp= a[j];
			int i=0;
			
		for(i=j;(i>=gap)&&(a[i-gap]>temp);i=i-gap)
		{
			a[i]=a[i-gap];
			
		}
		a[i]=temp;
		}
	}
}

int main(){
	int n;
	cout<<"enter array size:\n";
	cin>>n;
	int a[n];
	cout<<"enter array element\n";
	for (int i=0;i<n;i++){
		cin>>a[i];
	}
	
	shellsort(a, n);
	cout<<"sorted array are:\n";
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<"\t";
	}
	
	return 0;
	
}
