#include<iostream>
#include<conio.h>
#include<stdlib.h>
#define SIZE 10
using namespace std;
int main(){
	int a[SIZE],i,option,n,key;
	while(1){
		cout<<"Select Option\n";
		cout<<"1.enter element\n";
		cout<<"2.Search\n";
		cout<<"3.Quit\n";
		cin>>option;
		switch (option){
			case 1:
				{
					cout<<"ENter Number of element want to be enter\n";
					cin>>n;
					cout<<"Enter element one by one\n";
					for(i=0;i<n;i++)
					cin>>a[i];
					break;
				}
			case 2:
				{
					cout<<"enter element to be found\n";
					cin>>key;
					for(i=0;i<n;i++){
					if(key==a[i]){
						cout<<"elemet found\n";
						break;
					}}
					if(key!=a[i])
					{
						cout<<"elemet not found\n";
						break;
					
				}
				}
			case 3:
				{
					exit(0);
					break;
				}
		}
		
	}
	getch();
}
