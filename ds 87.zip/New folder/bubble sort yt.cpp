
// bubble sort

#include<iostream>
using namespace  std;
int main()
{
	int i,j,temp;
	int a[5];
	cout<<"enter 5 element\n";
	for(i=0;i<5;i++)
	cin>>a[i];
	cout<<"input elemet are:\n";
	for(i=0;i<5;i++)
	cout<<a[i]<<"\t";
	cout<<endl;
	for(i=0;i<5;i++)
	{
		for(j=i+1;j<5;j++)
		if (a[i]>a[j])
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
	}
	cout<<"sorted are:\n";
	for(i=0;i<5;i++)
	cout<<a[i]<<"\t";
	
	return 0 ;
}
